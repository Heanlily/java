package com.mercury.oop;

// Immutable class
public final class Student {

    // final class member variables must be initialized
    // when they are declared or using constructor
    // private: comply to encapsulation
    private final String name;
    private final int age;

    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    // NO setters!!!

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}
