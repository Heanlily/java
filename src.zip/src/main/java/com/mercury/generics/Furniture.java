package com.mercury.generics;

public class Furniture {
}
