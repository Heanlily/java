package com.mercury.generics;

public class Desk extends Furniture {
}
