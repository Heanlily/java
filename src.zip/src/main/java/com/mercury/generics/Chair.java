package com.mercury.generics;

public class Chair extends Furniture {
}
