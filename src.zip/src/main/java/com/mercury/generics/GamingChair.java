package com.mercury.generics;

public class GamingChair extends Chair {
}
