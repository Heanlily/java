package com.mercury.generics;

// T is a variable of type
public class Room<T> {

    // a room can has one chair or one desk.
    T something;

}

class Demo <T, R, W> {
    T x;
    R y;
    W z;
}