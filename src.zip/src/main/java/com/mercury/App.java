package com.mercury;

/**
 * Hello world!
 *
 */
public class App 
{

    // java App 1 2
    // args = {"1", "2"}

    // homework
    // simple calculator: +/-/*/div
    // java App 1 + 1
    // java App 2 * 2
    // java App 1 1 -> corner case
    // java App 1
    // java App
    // java App 1 @ 1

    public static void main( String[] args )
    {
        for (int i = 0; i < args.length; i++) {
            System.out.println(args[i]);
        }
    }
}
